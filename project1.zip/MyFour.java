public class MyFour <T>{
private T item1,item2,item3,item4,x1;
   MyFour(T item1,T item2,T item3,T item4){
   this.item1=item1;
   this.item2=item2;
   this.item3=item3;
   this.item4=item4;
   }
      public boolean allEqual(){
      if(item1.equals(item2) && item1.equals(item3) && item1.equals(item4)){
      return true;
       }
       else 
       return false;
       }
       public void shiftLeft(){
       x1=item1;
       item1=item2;
       item2=item3;
       item3=item4;
       item4=x1;  
      }
      public String toString(){
      return ("("+item1+","+item2+","+item3+","+item4+")");
      }
      public static void main(String[] args){
      java.util.Scanner sc=new java.util.Scanner(System.in);
      System.out.println("Enter four string values to compare:");
      String item1,item2,item3,item4;
      item1=sc.next();
      item2=sc.next();
      item3=sc.next();
      item4=sc.next();
      MyFour<String> mfs= new MyFour<>(item1,item2,item3,item4);
      System.out.println(mfs);
      System.out.println(mfs.allEqual());
      System.out.println("Enter four integer values:");
      int n1,n2,n3,n4;
      n1=sc.nextInt();
      n2=sc.nextInt();
      n3=sc.nextInt();
      n4=sc.nextInt();
      MyFour<Integer> mfi= new MyFour<>(n1,n2,n3,n4);
      System.out.println(mfi);
      System.out.println(mfi.allEqual());
      mfs.shiftLeft();
      mfi.shiftLeft();
      System.out.println(mfs);
      System.out.println(mfi);
      }
}