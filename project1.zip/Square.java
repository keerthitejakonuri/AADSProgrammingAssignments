class Square{
private double length;
   public Square(){
   this.length=1;
   }
   public Square(double length){
   this.length=length;
   }
   public double getArea(){
   return length*length;
   }
   public static void main(String[] args){
      Square s= new Square();
      java.util.Scanner sc= new java.util.Scanner(System.in);
      System.out.println("Enter the length of the square:");
      double l=sc.nextDouble();
      Square s1=new Square(l);
   System.out.println("The area of the square is "+ s.getArea());
   System.out.println("The area of the square is "+ s1.getArea());
   }
}