import java.util.Scanner;
class EvaluateTemperature{
   public static void main(String[] args){
      Scanner s= new Scanner(System.in);
      System.out.println("Do you want to enter temperature in celsius or fahrenheit. If celsius enter c, else if fahrenheit enter f:");
      char ch=s.next().charAt(0);
      
      System.out.println("Enter the temperature in celsius:");
      int c=s.nextInt();
      if(ch=='c'|| ch=='C'){
      double f=c*9/5+32;
      System.out.println("The corresponding temperature in fahrenheit is "+f+" degrees");
      if(f<0)
      System.out.println("Extremely cold");
      else if(f<=32)
      System.out.println("Very cold");
      else if(f<=50)
      System.out.println("Cold");
      else if(f<=70)
      System.out.println("Mild");
      else if(f<=90)
      System.out.println("Warm");
      else if(f<=100)
      System.out.println("Hot");
      else
      System.out.println("Very hot");

      }
   }
}