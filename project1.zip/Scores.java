import java.util.Scanner;
class Scores{
   public static void main(String[] args){
      Scanner s= new Scanner(System.in);
      String name[]= new String[10];
      int scores[][]= new int[10][5];
      System.out.println("Enter the values of TEN different people in order as shown below");
      System.out.println("Name  "+"Quiz1"+"Quiz2"+"Quiz3"+"Quiz4"+"Quiz5");
      for(int i=0;i<10;i++){
      System.out.println("Enter the name of person"+(i+1));
      name[i]=s.next();
      double total=0;
         for(int j=0;j<5;j++){
         System.out.print("Enter the marks of "+name[i]+" in quiz"+(j+1)+":");
      scores[i][j]=s.nextInt();
      total=total+scores[i][j];
            }  
      System.out.println("The average score of "+name[i]+" is "+ total/5);
      }
   }
}