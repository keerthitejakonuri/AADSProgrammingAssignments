public class Edge {
    
    int u;
    int v;
    int cost; 
    
    public Edge(int cost) {
    	this.cost = cost;
    }
    
    public int getu() {
        return u;
    }

    public void setu(int u) {
        this.u = u;
    }

    public int getv() {
        return v;
    }

    public void setv(int v) {
        this.v = v;
    }

	  
    
}
