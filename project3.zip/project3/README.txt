1.Open .java file in jGrasp IDE
2.Compile the file
3.Run the file.
This program works for only String values as parameters.
To give your own input just edit the readme file.
Also I took my own values in my main function. You can check with your own values.
