public class GenBinTree<T extends Comparable<? super T>>
{
/*
1.BinaryNode class 
2.Each Node has an Element and Two pointers to Left child and Right child
*/
   private static class BinaryNode<T>
   {
   T element;
   BinaryNode<T> left;
   BinaryNode<T> right;
      BinaryNode(T element)
      {
         this(element,null,null);
      }
      BinaryNode(T element,BinaryNode<T> left,BinaryNode<T> right)
      {
      this.element=element;
      this.left=left;
      this.right=right;
      }
   }
   private BinaryNode<T> root;   //Root node that is common for the whole program.
   /*
   1.add function adds an element to the existing tree in the order of specified string
   */
   public void add(T x)
   {
   if(!find(x))
   root=add(x,root);
   }
   private BinaryNode<T> add(T x,BinaryNode<T> t)
   {
   return new BinaryNode<T>(x,null,null);
   }
   int i;
   public void add(String position,T x)
   {
   i=0;
   BinaryNode<T> temp;
   if(!find(x))
   temp=add(position,x,root);
   }
   private BinaryNode<T> add(String position, T x, BinaryNode<T> t)
   {
      if(i==position.length()-1)
      {
         if(position.charAt(i)=='L'||position.charAt(i)=='l')
         {
            if(t.left!=null)
            {
            System.out.println(t.left.element+" is replaced with "+x);
            t.left.element=x;
            }
            else
            {
            t.left=new BinaryNode<T>(x,null,null);
            System.out.println("New Element "+x+" is added");
            }
         }
         else if(position.charAt(i)=='R'||position.charAt(i)=='r')
         {
            if(t.right!=null)
            {
            System.out.println(t.right.element+" is replaced with "+x);
            t.right.element=x;
            }
            else
            {
            t.right=new BinaryNode<T>(x,null,null);
            System.out.println("New Element "+x+" is added");
            }
         }
      }
      else if(position.charAt(i)=='L'||position.charAt(i)=='l')
      {
      i++;
     t.left= add(position,x,t.left);
      }
      else if(position.charAt(i)=='R'||position.charAt(i)=='r')
      {
      i++;
      t.right=add(position,x,t.right);
      }
      return t;
   }   
   /*
   1.Remove function removes the specified node only if it is aleaf.
   */
   public BinaryNode<T> remove(T x)
   {
   return remove(x,root);
   }
   private BinaryNode<T> remove(T x,  BinaryNode<T> y)
   {
      if( null != y)
      {
         if( x.compareTo(y.element)==0)                                    //checking for equality
         {
            if( y.left == null || y.right == null)                         // leaf node condition
            {
               System.out.println("Element "+x+" Removed");
               return y.left;
            }
            else
               System.out.println("Element is not leaf node");             // Element exists but not a leaf
         }  
         y.left = remove(x, y.left);
         y.right = remove(x, y.right);
      }   
      return y;
   }
   /*
   1.find function returns true if the element exists else it returns false
   */
   public boolean find(T x)
   {
      return find(x,root);
   }
   private boolean find(T x,BinaryNode<T> t)
   {
   boolean temp;
      if(t!=null)
      {
         if(x.compareTo(t.element)==0)                         //checking for equality
         {
         System.out.println("Element "+x+ " found");
         return true;
         }
         else
         {
         temp=find(x,t.left);
            if(temp==false)
            {
            temp=find(x,t.right);
            }
            return temp;
         }
      }
          return false;
   }
   /*
   1.swap function swaps the child links
   */
   public void swap(T x)
   {
   root = swap(x,root);
   System.out.println();
   System.out.print("Tree after swapping");
   print();
   }
   
   private BinaryNode<T> swap(T x,BinaryNode<T> t)
   {
      BinaryNode<T> temp;
   
      if(t!=null)
      {
         if(x.compareTo(t.element)==0)
         {
            temp=t.left;
            t.left=t.right;
            t.right=temp;
            return t;
         }
         t.left=swap(x,t.left);
         //if(flag==false)
         t.right=swap(x,t.right);
      }
   return t;
   }
   /*
   1.Mirror function makes the tree as it's mirror image.
   */
   public void mirror()
   {
    mirror(root);
    System.out.println();
    System.out.print("Mirror Image is");
    print();
   }
   private BinaryNode<T> mirror(BinaryNode<T> t)
   {
      if(t!=null)
      {
      BinaryNode<T> temp=t.left;
       t.left=t.right;
       t.right=temp;
       mirror(t.left);
       mirror(t.right);
      }
      return t;
   }
   /*
   1. rotateRight function rotates the node if possible
   2.rotateRight is equal to AVL-singleRoatation.
   */
   public void rotateRight(T x)
   {
   if(!find(x))
   {
   System.out.println("Element "+x+" not Found");
   return;
   }
   rotateRight(x,root);
   }
   private void rotateRight(T x,BinaryNode<T> t)
   {
   BinaryNode<T> temp;
         if(x.compareTo(root.element)==0)
         {
         temp=root.left;
         root.left=temp.right;
         temp.right=root;
         root=temp;
         return;
         }
         else
         {
            if(t!=null)
            {
               if(t.left!=null)
               {
                  if(x.compareTo(t.left.element)==0)
                  {
                  BinaryNode<T> node1,node2;
                  node2=t.left;
                  node1=node2.left;
                  if(node2.left==null)
                  {
                  System.out.println("Right Rotation of "+x+" is not possible in this scenario");
                  return;
                  }
                  node2.left=node1.right;
                  node1.right=node2;
                  t.left=node1;
                  return;
                  }
               }
               if(t.right!=null)
               {
                  if(x.compareTo(t.right.element)==0)
                  {
                  BinaryNode<T> node1,node2;
                  node2=t.right;
                  node1=node2.left;
                  if(node2.left==null)
                  {
                  System.out.println("Right Rotation of "+x+" is not possible in this scenario");
                  return;
                  }
                  node2.left=node1.right;
                  node1.right=node2;
                  t.right=node1;
                  return;
                  }
               }
               rotateRight(x,t.left);
               rotateRight(x,t.right);
            }
         }
 }
 /*
   1. rotateLeft function rotates the node if possible
   2.rotateLeft is equal to AVL-singleRoatation.
   */

public void rotateLeft(T x)
{
   if(!find(x))
   {
   System.out.println("Element "+x+" not Found to rotate left");
   return;
   }
 rotateLeft(x,root);
}
private void rotateLeft(T x,BinaryNode<T> t)
{
   BinaryNode<T> temp;
   if(x.compareTo(root.element)==0)
         {
         temp=root.right;
         root.right=temp.left;
         temp.left=root;
         root=temp;
         return;
         }
    else
         {
            if(t!=null)
            {
               if(t.right!=null)
               {
                  if(x.compareTo(t.right.element)==0)
                  {
                  BinaryNode<T> node1,node2;
                  node2=t.right;
                  node1=node2.right;
                  if(node2.right==null)
                  {
                  System.out.println("Left Rotation of "+x+" is not possible in this scenario");
                  return;
                  }
                  node2.right=node1.left;
                  node1.left=node2;
                  t.right=node1;
                  return;
                  }
               }
               if(t.left!=null)
               {
                  if(x.compareTo(t.left.element)==0)
                  {
                  BinaryNode<T> node1,node2;
                  node2=t.left;
                  node1=node2.right;
                  if(node2.right==null)
                  {
                  System.out.println("Left Rotation of "+x+" is not possible in this scenario");
                  return;
                  }
                  node2.right=node1.left;
                  node1.left=node2;
                  t.left=node1;
                  return;
                  }
               }
               rotateLeft(x,t.left);
               rotateLeft(x,t.right);
            }
         }

}

   public void preOrder()
   {
   preOrder(root);
   }
   private void preOrder(BinaryNode<T> t)
   {
      if(t!=null)
            {
            System.out.print( t.element+" " );
            preOrder( t.left );
            preOrder( t.right );
            }
   } 
private static int count;
/*
1.countNodes function counts the number of nodes in the tree.
*/
   public int countNodes()
   {
   count = 0;
   return countNodes(root);
   }
   private int countNodes(BinaryNode<T> t)
   {
            if(t!=null)
            {
            countNodes( t.left );
            count++;
            countNodes( t.right );
            }
      return count;
   }
   public void print()
   {
   System.out.println();
   print(root);
   }
   /*
   1.print function prints the node of the tree in In-order
   */
   private void print( BinaryNode<T> t )
    {
            if(t!=null)
            {
            print( t.left );
            System.out.print( t.element+" " );
            print( t.right );
            }
    }
    public static void main(String[] args)
    {
    GenBinTree <String> myTree =new GenBinTree<>();
   myTree.add("100");
   myTree.add("L", "50");
   myTree.add("R", "150");
   myTree.add("LL", "40");
   myTree.add("LLR", "45");
   myTree.add("LLL", "30");
   myTree.add("LLLL", "20");
        myTree.add("RR", "152");
        myTree.add("RRR", "153");
        myTree.add("RRRR", "154");
        myTree.add("RRL", "151");
        myTree.add("LLRL", "44");
        myTree.print();
        myTree.add("L", "60");
        myTree.print();
        myTree.add("L", "40");
        myTree.find("44");
        myTree.remove("44");
        myTree.find("44");
        myTree.find("154");
        myTree.remove("152");
        myTree.remove("154");
        myTree.remove("82");
        myTree.remove("100");
        myTree.print();
        myTree.swap("100");
    	myTree.swap("83");
    	myTree.swap("153");
    	myTree.rotateRight("100");
    	myTree.rotateRight("153");
    	myTree.rotateRight("100000");
    	myTree.rotateLeft("100");
    	myTree.rotateLeft("30");
    	myTree.rotateLeft("400");
    	myTree.mirror();
      System.out.println();
      myTree.print();
      System.out.println();
    	System.out.println(myTree.countNodes());
    }
}
